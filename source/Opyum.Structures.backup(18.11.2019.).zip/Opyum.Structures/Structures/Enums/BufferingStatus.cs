﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opyum.Structures
{
    public enum BufferingStatus
    {
        Empty = 0,
        Buffering = 1,
        Done = 2
    }
}
