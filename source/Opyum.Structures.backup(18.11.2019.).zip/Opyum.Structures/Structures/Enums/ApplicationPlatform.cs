﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opyum.Structures.Enums
{
    public enum ApplicationPlatform
    {
        Windows = 1,
        WPF = 2,
        WebApp = 4,
    }
}
