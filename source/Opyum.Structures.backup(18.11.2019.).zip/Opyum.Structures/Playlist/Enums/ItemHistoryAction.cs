﻿namespace Opyum.Structures.Playlist
{
    public enum ItemHistoryAction
    {
        None = 0,
        Play = 1,
        Delete = 2
    }
}
