﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opyum.Structures.Playlist
{
    public enum DurationType
    {
        Set = 0,
        Dynamic = 1
    }
}
