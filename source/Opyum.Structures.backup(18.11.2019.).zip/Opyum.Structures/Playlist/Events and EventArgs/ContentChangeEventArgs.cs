﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opyum.Structures.Playlist
{
    public class ContentChangeEventArgs : EventArgs
    {
        ///needs to know what part of the content has changed.
    }
}
