﻿namespace Opyum.Structures.Playlist
{
    /// <summary>
    /// Audio information.
    /// <para>The standard things it contains should be simillar to a ID3 tag, incčluding an ID3 tag.</para>
    /// </summary>
    public class AudioInfo
    {
        









        /// <summary>
        /// UNFINISHED
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        public static AudioInfo Generate(IContent content)
        {
            return new AudioInfo();
        }
    }
}
