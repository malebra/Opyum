﻿namespace Opyum.Structures.Playlist
{
    public class PlaylistItemAccessor
    {
    }
}
