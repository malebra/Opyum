﻿using System;
using System.Collections.Generic;

namespace Opyum.Structures.Playlist
{
    /// <summary>
    /// Resolves requests for contents.
    /// <para>If the content is a file path, then all the data will be loaded from the file info (and passed through to the file manager for redundancy control)</para>
    /// <para>If the content is a db querry, all the data will be loaded from the db.</para>
    /// <para>If the content is s stream, the data will be loaded from the stream (if present).</para>
    /// </summary>
    public class ContentResolver : IDisposable
    {
        protected internal static List<ContentResolver> AllResolvers = new List<ContentResolver>();

        protected ContentResolver()
        {
            AllResolvers.Add(this);
        }

        ~ContentResolver()
        {
            AllResolvers.Remove(this);
        }


        public ContentResolver(string path) : this()
        {
            
        }

        /// <summary>
        /// <para>UNFINSHED</para>
        /// <para>UNFINSHED</para>
        /// <para>UNFINSHED</para>
        /// <para>UNFINSHED</para>
        /// Sets up the <see cref="ContentResolver"/> so that it can track wheather the file changes.
        /// </summary>
        /// <param name="source"></param>
        public void Setup(string source)
        {

        }



        /// <summary>
        /// UNFINISHED
        /// UNFINISHED
        /// UNFINISHED
        /// </summary>
        /// <returns></returns>
        public static ContentResolver AssignContentResolver()
        {
            return new ContentResolver();
        }

        #region GarbageCollection

        public void Dispose()
        {
            Dispose(true);
            GC.Collect();
        }

        public void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }

        #endregion


    }
}
