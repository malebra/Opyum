﻿namespace Opyum.Structures.Playlist
{
    public interface IItemOptions
    {
    }
}
