﻿namespace Opyum.Structures.Playlist
{
    public class BaseOptions : IItemOptions
    {
    }
}
