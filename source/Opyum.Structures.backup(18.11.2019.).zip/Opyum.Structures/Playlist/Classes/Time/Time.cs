﻿namespace Opyum.Structures.Playlist
{
    public class Time : ITime
    {
        
    }
}
