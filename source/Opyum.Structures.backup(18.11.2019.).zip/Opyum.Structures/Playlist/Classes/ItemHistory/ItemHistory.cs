﻿namespace Opyum.Structures.Playlist
{
    public class ItemHistory
    {

        public void Report(object reporter)
        {
            
        }

        public void Action(ItemHistoryAction action)
        {
            
        }

        
    }

    
}
