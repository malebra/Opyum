﻿namespace Opyum.Structures.Playlist
{
    public class Tags : ITags
    {

    }
}
