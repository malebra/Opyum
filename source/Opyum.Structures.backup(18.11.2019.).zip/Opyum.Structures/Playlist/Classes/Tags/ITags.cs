﻿namespace Opyum.Structures.Playlist
{
    public interface ITags
    {
    }
}
