﻿namespace Opyum.Structures.Playlist
{
    public class AudioImage
    {

        public object Image { get; protected internal set; }

        public object ImageFormat { get; protected internal set; }

        public string ImageName { get; protected internal set; }
    }
}
