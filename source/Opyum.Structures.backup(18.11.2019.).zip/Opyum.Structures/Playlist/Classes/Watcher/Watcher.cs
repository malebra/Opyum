﻿namespace Opyum.Structures.Playlist
{
    public class Watcher : IWatcher
    {

    }
}
