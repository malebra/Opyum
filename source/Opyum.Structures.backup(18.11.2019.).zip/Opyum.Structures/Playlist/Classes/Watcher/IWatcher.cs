﻿namespace Opyum.Structures.Playlist
{
    public interface IWatcher
    {
        
    }
}