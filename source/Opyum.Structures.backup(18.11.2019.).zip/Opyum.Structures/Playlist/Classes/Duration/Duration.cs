﻿namespace Opyum.Structures.Playlist
{
    public class Duration : IDuration
    {
        
    }
}
