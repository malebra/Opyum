﻿namespace Opyum.Structures.Playlist
{
    public interface IDuration
    {

    }
}
