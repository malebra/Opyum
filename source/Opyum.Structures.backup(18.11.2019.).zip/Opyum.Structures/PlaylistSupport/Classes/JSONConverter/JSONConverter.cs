﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opyum.Structures.PlaylistSupport
{
    /// <summary>
    /// Used for conversion between PlaylistItem and JSON files
    /// </summary>
    public static class JSONConverter
    {
        
    }
}
